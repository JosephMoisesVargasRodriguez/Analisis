﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class___1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int Tam = 10;
            int sumap = 0, impp = 0;
            int[] numeros = new int[Tam];
            Console.WriteLine("Ingrese los datos del arreglo");
            Console.WriteLine();
            for (int i = 0; i < Tam; i++)
            {
                Console.Write("Ingrese un numero: ");
                numeros[i] = int.Parse(Console.ReadLine());

                if (numeros[i] % 2 == 0)
                {
                    sumap += numeros[i] + numeros[i];
                }
                else
                {
                    impp += numeros[i] + numeros[i];
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("--Datos del arreglo--");
            Console.WriteLine();
            for (int i = 0; i < Tam; i++)
            {
                Console.Write(numeros[i] + ", ");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("La suma de pares es {0}", sumap);
            Console.WriteLine();
            Console.WriteLine("La suma de pares es {0}", impp);

            Console.ReadKey();
        }
    }
}
