﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class___2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] tabla1 = new int[3, 3];
            int f, c;
            int sumaPares = 0, sumaImpares = 0;

            Console.WriteLine("Arreglos bidimensionales");
            Console.WriteLine();
            Console.WriteLine("Digite los datos del arreglo: ");

            // Lectura de los datos en el arreglo
            for (f = 0; f < 3; f++)
            {
                for (c = 0; c < 3; c++)
                {
                    tabla1[f, c] = int.Parse(Console.ReadLine());

                    // Verificar si el numero es par o impar
                    if (tabla1[f, c] % 2 == 0)
                    {
                        sumaPares += tabla1[f, c];  // Sumar los numeros pares
                    }
                    else
                    {
                        sumaImpares += tabla1[f, c];  // Sumar los numeros impares
                    }
                }
            }

            // Imprimir la tabla
            Console.WriteLine("Imprimiendo el arreglo...");
            for (f = 0; f < 3; f++)
            {
                for (c = 0; c < 3; c++)
                {
                    Console.Write("|" + tabla1[f, c] + "|");
                }
                Console.WriteLine();
            }

            // Imprimir la suma de pares e impares
            Console.WriteLine("La suma de los numeros pares es: " + sumaPares);
            Console.WriteLine("La suma de los numeros impares es: " + sumaImpares);

            Console.ReadKey();
        }
    }
}
